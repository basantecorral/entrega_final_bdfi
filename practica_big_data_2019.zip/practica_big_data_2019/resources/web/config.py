# config.py, a configuration file for index.py
RECORDS_PER_PAGE = 15
AIRPLANE_RECORDS_PER_PAGE = 5
ELASTIC_URL = 'http://kafka_bdfi:9092/agile_data_science'
